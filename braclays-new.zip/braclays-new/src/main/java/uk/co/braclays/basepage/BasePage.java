package uk.co.braclays.basepage;


import org.openqa.selenium.WebDriver;


public class BasePage {

    static public WebDriver driver;

    

}
