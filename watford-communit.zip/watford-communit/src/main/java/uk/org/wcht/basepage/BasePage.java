package uk.org.wcht.basepage;

import org.openqa.selenium.WebDriver;

public class BasePage {
    public static WebDriver driver;

}
