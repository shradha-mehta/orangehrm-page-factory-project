package uk.gov.harrow.basepage;

import org.openqa.selenium.WebDriver;

public class BasePage {
    public static WebDriver driver;
}
